<?php

$service_cards_pretitle = $service_cards_pretitle ?? 'SACRED OFFERINGS &amp; MODALITIES';
$service_cards_title    = $service_cards_title ?? 'Comprehensive <em>Holistic Services</em>';
$service_cards_subtitle = $service_cards_subtitle ?? 'Explore our tailored energy therapies, trauma recovery, and personal healing sessions held in a compassionate, non-judgmental sanctuary.';

$full_services_list = $full_services_list ?? [
    [
        'title' => 'Reiki Healing',
        'image' => 'assets/images/services/Reiki Healing.jpg',
        'desc'  => 'A deeply restorative Japanese energy therapy that channels universal life force to dissolve stagnant blocks, align chakras, and catalyze physical and emotional self-healing.',
        'url'   => 'contact.php?service=Reiki+Healing'
    ],
    [
        'title' => 'Crystal Healing',
        'image' => 'assets/images/services/Crystal Healing.jpg',
        'desc'  => 'Harnesses the natural vibrational resonance of pure earth crystals placed on sacred energy vortexes to cleanse auric fields, release stress, and inspire mental clarity.',
        'url'   => 'contact.php?service=Crystal+Healing'
    ],
    [
        'title' => 'Angel Healing',
        'image' => 'assets/images/services/Angel Healing.jpg',
        'desc'  => 'A gentle, high-vibrational healing modality connecting you with angelic guidance for divine protection, intuitive clarity, and profound emotional solace during life transitions.',
        'url'   => 'contact.php?service=Angel+Healing'
    ],
    [
        'title' => 'Energy healing',
        'image' => 'assets/images/services/Energy healing.jpg',
        'desc'  => 'Holistic biofield realignment that clears energetic fatigue, releases heavy emotional residue, and harmonizes your physical, emotional, and spiritual layers.',
        'url'   => 'contact.php?service=Energy+healing'
    ],
    [
        'title' => 'EFT',
        'image' => 'assets/images/services/EFT.jpg',
        'desc'  => 'Acupressure meridian tapping combined with mindful cognitive reframing to rapidly dissolve chronic anxiety, release trapped trauma, and rewire healthy thought patterns.',
        'url'   => 'contact.php?service=EFT'
    ],
    [
        'title' => 'Counselling',
        'image' => 'assets/images/services/Counselling.jpg',
        'desc'  => 'A safe, empathetic sanctuary offering confidential dialogue, emotional grounding, and practical holistic tools to navigate relationship hurdles and personal growth.',
        'url'   => 'contact.php?service=Counselling'
    ],
    [
        'title' => 'Trauma Healing',
        'image' => 'assets/images/services/Trauma Healing.jpg',
        'desc'  => 'Gentle somatic and energetic trauma recovery that supports the nervous system in discharging stored subconscious stress, restoring inner safety and lasting resilience.',
        'url'   => 'contact.php?service=Trauma+Healing'
    ],
    [
        'title' => 'Personal Transformation Healing',
        'image' => 'assets/images/services/Personal Transformation.jpg',
        'desc'  => 'An immersive, multi-layered journey addressing root subconscious patterns, unlocking emotional freedom, and empowering you to step boldly into your soul purpose.',
        'url'   => 'contact.php?service=Personal+Transformation+Healing'
    ],
    [
        'title' => 'Meditations',
        'image' => 'assets/images/services/Guided Meditation.jpg',
        'desc'  => 'Soulful mindfulness journeys, conscious pranayama breathwork, and guided visualization designed to quiet mental chatter, expand awareness, and ground profound inner peace.',
        'url'   => 'contact.php?service=Meditations'
    ],
    [
        'title' => 'Tarot Card reading',
        'image' => 'assets/images/services/Tarot Card Reading.jpg',
        'desc'  => 'Intuitive symbolic tarot readings offering illuminating perspectives, spiritual alignment, and actionable clarity for your relationships, career, and soul path.',
        'url'   => 'contact.php?service=Tarot+Card+reading'
    ],
    [
        'title' => 'Therapeutic Yoga',
        'image' => 'assets/images/services/Therapeutic Yoga.jpg',
        'desc'  => 'Conscious, therapeutic movement combined with restorative breath integration to release somatic holding patterns, improve flexibility, and nurture embodied vitality.',
        'url'   => 'contact.php?service=Therapeutic+Yoga'
    ],
];
?>

<section class="service-cards-section position-relative" id="servicesGrid" aria-label="Comprehensive Healing Services">
    <div class="container">
        
        <!-- Section Header -->
        <div class="service-cards-header text-center">
         
            <h2 class="service-cards-title"><?= $service_cards_title ?></h2>
           
        </div>

        <!-- 3-Column Service Cards Grid (Desktop: 3 cols, Tablet: 2 cols, Mobile: 1 col) -->
        <div class="row service-cards-row justify-content-center">
            <?php
                $service_slugs = [
                    'Reiki Healing'                     => 'reiki-healing',
                    'Crystal Healing'                   => 'crystal-healing',
                    'Angel Healing'                     => 'angel-healing',
                    'Energy healing'                    => 'energy-healing',
                    'EFT'                               => 'eft',
                    'Counselling'                       => 'counselling',
                    'Trauma Healing'                    => 'trauma-healing',
                    'Personal Transformation Healing'   => 'personal-transformation',
                    'Meditations'                       => 'meditations',
                    'Tarot Card reading'                => 'tarot-card-reading',
                    'Therapeutic Yoga'                  => 'therapeutic-yoga',
                ];
            ?>
            <?php foreach ($full_services_list as $index => $service): ?>
                <?php
                    $card_id = $service_slugs[$service['title']] ?? strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $service['title'])));
                ?>
                <div class="col-12 col-md-6 col-lg-4 d-flex align-items-stretch mb-4 service-card-col" id="<?= htmlspecialchars($card_id) ?>">
                    <article class="service-item-card">
                        
                        <!-- Top Image -->
                        <div class="service-item-media">
                            <img src="<?= htmlspecialchars($service['image']) ?>" 
                                 alt="<?= htmlspecialchars($service['title']) ?> at SS Healing Rays" 
                                 loading="lazy">
                        </div>

                        <!-- Card Body (Heading + Description + Enquire Button) -->
                        <div class="service-item-body">
                            <span class="service-item-number"><?= sprintf('%02d', $index + 1) ?>.</span>
                            <h3 class="service-item-title"><?= htmlspecialchars($service['title']) ?></h3>
                            <p class="service-item-desc"><?= htmlspecialchars($service['desc']) ?></p>
                            
                            <!-- Main Reusable Button Component from common/button.php -->
                            <div class="service-item-actions">
                                <?php
                                    $btn_text    = 'Enquire Now';
                                    $btn_url     = '#serviceBookingModal';
                                    $btn_class   = 'Btn-Card-Main w-100 justify-content-between';
                                    $clean_title = htmlspecialchars(html_entity_decode(strip_tags($service['title']), ENT_QUOTES, 'UTF-8'));
                                    $btn_attr    = 'data-bs-toggle="modal" data-bs-target="#serviceBookingModal" data-service-title="' . $clean_title . '" data-service-category="I. Healings" aria-label="Enquire about ' . $clean_title . '"';
                                    include dirname(__DIR__) . '/common/button.php';
                                ?>
                            </div>
                        </div>

                    </article>
                </div>
            <?php endforeach; ?>
        </div>

    </div>
</section>